# Script Get Bundling from x_x_x

## _This is a last update from me, no more making script_

[Powered By Matercar x Agatha](https://t.me/MaterIsCar)

## Features

1. Auto create + Get bundling
2. Using a Thread and Proxy

## Note:

- Open Source
- Tidak menjual/perbelikan script
- Mohon untuk tidak mengganti credit
- Respect Me Pls 😏
- Recode is allowed with credit

## How To Change Version

changes version in a main.py file

```sh
userAgent_vidio = "tv-android/1.92.1 (437)"
xApiInfo_vidio = "tv-android/13/1.92.1-437"
```

## Tele : [MaterACar](https://t.me/MaterACar)

## Thanks to my mentor [Agatha](https://t.me/chsangkara)
